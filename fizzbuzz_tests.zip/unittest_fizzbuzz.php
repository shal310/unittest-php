<?php

  require "fizzbuzz.php";
  class FizzBuzzTest extends PHPUnit_Framework_TestCase {
    public function test_divisible_by_3() {
      $num = 3;

      $this->assertEquals(True, is_divisible_by_3($num));
    }
    
  }
?>
 
