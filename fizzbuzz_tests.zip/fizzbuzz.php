<?php

function is_divisible_by_3_and_5($num) {
  return is_divisible_by_5($num) && is_divisible_by_3($num);
}

function is_divisible_by_5($num) {
  return $num % 5 == 0;
}

function is_divisible_by_3($num) {
  return $num % 3 == 0;
}

function fizz_buzz(){
  for ($i=0; $i<100; $i++){
    echo "\n";
    if(is_divisible_by_3_and_5($i)){
      echo "FizzBuzz";
    }
    else if(is_divisible_by_3($i)){
      echo "Fizz";
    }
    else if(is_divisible_by_5($i)){
      echo "Buzz";
    }
    else {
      echo $i;
    }
  }
}

fizz_buzz()
?>
